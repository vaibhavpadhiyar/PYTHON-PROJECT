import pandas as pd
import numpy as np

print("\n---2. Grouping---")
sales_data = {
    'Product': ['Laptop', 'Mouse', 'Keyboard', 'Laptop', 'Mouse', 'Keyboard'],
    'Region': ['North', 'North', 'South', 'South', 'North', 'South'],  # Corrected capitalization
    'Sales': [1200, 25, 75, 1500, 30, 80]
}
sales_df = pd.DataFrame(sales_data)
print(f"Original Sales DataFrame:\n{sales_df}\n")

product_groups = sales_df.groupby('Product')
print("Grouped by 'Product' (not yet aggregated):")
print(product_groups.first())

print("\n---3. Aggregating---")  # Corrected spelling
total_sales = sales_df.groupby('Product')['Sales'].sum()
print(f"Total sales per product:\n{total_sales}\n")

average_sales = sales_df.groupby('Region')['Sales'].mean()
print(f"Average sales per region:\n{average_sales}\n")

aggregated_df = sales_df.groupby('Product').agg({
    'Sales': ['sum', 'mean', 'count']
})
print(f"Multiple aggregations:\n{aggregated_df}\n")

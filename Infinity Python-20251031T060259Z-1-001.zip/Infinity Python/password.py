def evaluate_score(score):
  print(f"Evaluating score: {score}")
  if score >=90:
     print("Excellent! Your grade is A.")
  elif score >= 80:
     print("Well done! Your grade is B.")
  elif score >= 70:
     print("Good job! Your grade is C.")
  elif score >= 60:
     print("You passed. Your grade is D.")
  else:
    print("Unfortunately, your grade is F.")
print("---Grade Evaluation System---")
evaluate_score(85)
evaluate_score(92)
evaluate_score(55)
evaluate_score(65)  

def check_pass(password):
  if len(password)>=8:
    if any(char.isdigit() for char in password):
      print("Password is Valid!")
    else:
      print("Password is long enough,but lacks of digit!")
  else:
      print("Password is too short!")
print("---Evaluating passwords---")
check_pass("short")
check_pass("short_Pass_12345")
check_pass("short_password")
import pandas as pd
import numpy as np
print("---1. Series and DatatFrames ---")
s = pd.Series([10,20,30,40,50], name ="Numbers")
print(f"Simple Series: \n{s}\n")

data = {
			'City': ['Mumbai', 'Delhi', 'Chennai', 'Kolkata'], 
			'Population': [20,19,11,15], 
			'Area_sq_km':[603,1484,426,185]
}
df = pd.DataFrame(data)
print(f"Dataframe createed from a dictionary:\n{df}\n")
print("---Multi-level index Series---")
index_tuples = [
					 ('GroupA', 'Item1'), ('GroupA', 'Item2'),
					 ('GroupB', 'Item1'), ('GroupB', 'Item2')]
multi_index = pd.MultiIndex.from_tuples(index_tuples, name=['Group', 'Item'])
multilevel_s = pd.Series([100,200,300,400], index = multi_index)
print(f"Multi-level Index Series:\n{multilevel_s}\n")

print("Accessing data from 'GroupA':")
print(multilevel_s.loc['GroupA'])		

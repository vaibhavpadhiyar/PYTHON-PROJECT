def demonstrate_loop():
	print("---1. Using a Loop ---")
	fruits = ["apple", "banana", "cherry"]
	print("Iterating through a list of fruits: ")
	for fruit in fruits:
		print(f" - {fruits}")
	print("\nIterating through a range from 0 to 4: ")
	for i in range(5):
		print(f" - Count: {i}")
def demonstrate_while_loop():
	print("\n---2. Using a while loop ---")
	count = 0
	print("Counting upto 5: ")
	while count < 5:
		print(f" - count is {count}")
		count += 1
def demonstrate_loop_control():
	print("\n---3. Using break and continue ---")
	print("Example of 'break':")
	for num in range(10):
		if num == 5:
			print(" - 5 found. Breaking the loop")
			break
		print(f" - Processing number: {num}")
	print("\nExample of 'continue':")
	for num in range(5):
		if num == 2:
			print(" - Skipping number 2.")
			continue
		print(f" - processing number: {num}")
demonstrate_loop()
demonstrate_while_loop()
demonstrate_loop_control()
import sqlite3
def run_database_operations():
	conn=None
	try:
		conn = sqlite3.connect('example.db')
		print("connected to the database successfully.")

		cursor = conn.cursor()
		cursor.execute('''CREATE TABLE IF NOT EXISTS users ( id INTEGER PRIMARY KEY,name TEXT NOT NULL, email TEXT NOT NULL UNIQUE )''')
		print("Table 'users' created or already exists.")
		
		users_to_insert = [('Alice', 'alice@example.com'), ('Bob', 'bob@example.com'), ('Charlie', 'charlie@example.com')]
		cursor.executemany("INSERT INTO users (name, email) VALUES(?,?)", users_to_insert)
		print("Inserted new records into table.")
		conn.commit()

		print("\n---Reading all records---")
		cursor.execute("SELECT id, name, email FROM users")
		rows = cursor.fetchall()
		for row in rows:
			print(f"ID: {row[0]}, Name:{row[1]}, Email:{row[2]}")
		print("\n---Updating a record---")
		cursor.execute("UPDATE users SET email = ? WHERE name = ?", ('robert@example.com','Bob'))
		print("Updated Bob's email.")
		conn.commit()
		
		print("\n---Deleting a record---")
		cursor.execute("DELETE FROM users WHERE name = ?",('Charlie',))
		print("Deleted Charlie's record.")
		conn.commit()

		print("\n---Reading records after update and delete---")
		cursor.execute("SELECT id, name,email FROM users")
		rows = cursor.fetchall()
		for row in rows:
			print(f"ID: {row[0]}, Name: {row[1]}, Email: {row[2]}")

	except sqlite3.IntegrityError as e:
		print(f"\n Database error: {e}. Record may already exist.")
	except sqlite3.Error as e:
		print(f"\nAn error occurred:{e}")
	finally:
		if conn:
			conn.close()
			print("\nDatabase connection closed.")
if __name__ == "__main__":
	run_database_operations()
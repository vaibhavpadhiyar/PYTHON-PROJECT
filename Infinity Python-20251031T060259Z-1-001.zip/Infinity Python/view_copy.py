import numpy as np
print("\n---4. Array views vs copies ---")
original_array = np.arange(5)
print(f"Original array: {original_array}")
view_array = original_array.view()
view_array[0] = 99
print(f"View array after modification: {view_array}")
print(f"Original array after view modification: {original_array}")
original_array = np.arange(5)
copy_array = original_array.copy()
copy_array[0] = 100
print(f"\n Copy array after modification : {copy_array}")
print(f"Original array after copy modification: {original_array}")
import numpy as np
print("---5. manipulating the arrays---")
array_1d = np.arange(12)
print(f"Original 1D array: {array_1d}")
array_2d =array_1d.reshape(3,4)
print(f"reshape to 3 X 4 : \n{array_2d}")
flattened_array = array_2d.flatten()
print(f"flattened array: {flattened_array}")
transposed_array=array_2d.T
print(f"Transposed array: {transposed_array}")

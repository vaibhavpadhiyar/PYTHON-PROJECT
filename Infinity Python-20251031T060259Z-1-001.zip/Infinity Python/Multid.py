import numpy as np
print("---3. Creating Multidimensional array ---")
my_matrix = np.array([[1,2,3] ,[4,5,6]])
print(f"2 X 3 matrix: \n{my_matrix}")
print(f"Element in row 1,coloumn 2: {my_matrix[1,2]}")
print(f"First column : {my_matrix[ ,: ]}")
print("-" * 30)
